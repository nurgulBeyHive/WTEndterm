from django.shortcuts import render, redirect
from django.views.decorators.http import require_POST

from .models import Blog
from .forms import BlogForm

def index(request):
    blog_list = Blog.objects.order_by('id')

    form = BlogForm()

    context = {'blog_list' : blog_list, 'form' : form}

    return render(request, 'blog/index.html', context)

@require_POST
def addBlog(request):
    form = BlogForm(request.POST)

    if form.is_valid():
        new_blog = Blog(text=request.POST['text'])
        new_blog.save()

    return redirect('index')


