from django import forms 

class BlogForm(forms.Form):
    text = forms.CharField(max_length=40, 
        widget=forms.TextInput(
            attrs={'class' : 'form-control', 'placeholder' : 'Enter', 'aria-label' : 'Blog', 'aria-describedby' : 'add-btn'}))